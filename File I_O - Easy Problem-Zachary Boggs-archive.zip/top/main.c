// Zachary Boggs
// Cop 3223C
// 11/11/23

#include "main.h"
#include <ctype.h>
#include <stdio.h>

// checks if the character is a vowel
int isVowel(char c) {
  c = tolower(c); // converts the letters to lowercase
  return (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u');
}

int main(void) {
  char inputFilename[31], outputFilename[31];
  scanf("%30s", inputFilename);
  scanf("%30s", outputFilename);

  // opens the input files for reading
  FILE *inputFile = fopen(inputFilename, "r");
  if (inputFile == NULL) {
    printf("Error opening file.\n");
    return 1;
  }
  // opens the output file for writing
  FILE *outputFile = fopen(outputFilename, "w");
  if (outputFile == NULL) {
    printf("Error opening file.\n");
    return 1;
  }
  // taking the characters from the input file
  char c;
  int charCount = 0, vowelCount = 0, digitCount = 0;
  while ((c = fgetc(inputFile)) != EOF) {
    // converts the lowercase to upper case
    fputc(toupper(c), outputFile);
    // counts the number of characters digits and vowels
    if (c != '\n') {
      charCount++;
      if (isVowel(c)) {
        vowelCount++;
      }
      if (isdigit(c)) {
        digitCount++;
      }
    }
  }
  // closes the files
  fclose(inputFile);
  fclose(outputFile);

  // displays information
  inputFile = fopen(inputFilename, "r");
  while ((c = fgetc(inputFile)) != EOF) {
    putchar(c);
  }
  // closes files
  fclose(inputFile);
  // prints out the characters, vowels, and digits
  printf("\nNumber of characters: %d\n", charCount);
  printf("Number of vowels: %d\n", vowelCount);
  printf("Number of digits: %d\n", digitCount);
  return 0;
  return 0;
}