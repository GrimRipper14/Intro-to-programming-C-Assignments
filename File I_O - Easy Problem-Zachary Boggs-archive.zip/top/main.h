int isVowel(char c);
