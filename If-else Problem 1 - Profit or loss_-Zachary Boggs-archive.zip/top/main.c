// Danielle Durden
// Cop 3223C

#include <stdio.h>

int main(void) {
  // defining the variables as floats
  float cost, selling, loss;
  printf("Enter the cost price and selling price: \n");
  scanf("%f %f", &selling, &cost);
  // calculation for loss/profit
  loss = cost - selling;
  // decides if value is a loss or a profit
  if (loss > 0) {
    printf("You made a profit. \n");
    printf("The amount of profit is $%.2f\n", loss);
  } else if (loss < 0) {
    printf("You incurred loss. \n");
    printf("The amount of loss is $%.2f\n", -loss);
  }
  return 0;
}