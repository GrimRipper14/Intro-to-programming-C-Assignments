#include <stdio.h>

int main(void) {
  float f, c;
  printf("Enter the temperature in Fahrenheit: \n");
  scanf("%f", &f);
  // math for pemdas
  c = (f - 32) * 5 / 9;
  // this prints the temp in celsius
  printf("The temperature in Celsius is: %f\n", c);
  return 0;
}