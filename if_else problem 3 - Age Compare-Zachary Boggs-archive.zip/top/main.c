// Zachary Boggs
// COP 3223
// 9/13/23
#include <stdio.h>

int main(void) {
  int age1, age2, age3;
  printf("Enter ages of three people (person 1, person 2, and person 3):\n");
  scanf("%d %d %d", &age1, &age2, &age3);

  //compares the first person age to other two
  if (age1 < age2 && age1 < age3) {
    printf("Person 1 is youngest");
  }

  //compares the second person age to other two 
  else if (age2 < age1 && age2 < age3) {
    printf("Person 2 is youngest");
  }

  // states the third person is the youngest if other two conditions arent met
  else {
    printf("Person 3 is youngest");
  }

  return 0;
}