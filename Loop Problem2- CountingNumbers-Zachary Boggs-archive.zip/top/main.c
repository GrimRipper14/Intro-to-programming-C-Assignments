// Zachary Boggs
// Loop problem 2
// COP 3223C
// 10/1/23
#include <stdio.h>

int main(void) {
  // sets up the variables
  int num;
  int nn = 0;
  int pn = 0;
  int zn = 0;
  printf("Input the number:\n");
  // sets the while loop
  while (1) {
    scanf("%d", &num);
    if (num == -100) {
      printf("Number of positive numbers: %d\n", pn);
      printf("Number of negative numbers: %d\n", nn);
      printf("Number of zero: %d\n", zn);
      break;
    } else if (num > 0) {
      pn++;
    } else if (num < 0) {
      nn++;
    } else {
      zn++;
    }
  }
  return 0;
}