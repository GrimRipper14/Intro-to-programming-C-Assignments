#define MAX_LENGTH 101
int getLength(char s[]);
int is_equal(char s1[], char s2[]);
void str_copy(char dest[], char source[]);
void swap(char *a, char *b);
void str_reverse(char s[]);
int is_palindrome(char s[]);
void capitalize_word(char *str);