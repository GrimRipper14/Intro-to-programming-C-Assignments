//Zachary Boggs
// COP 3223C
// 11/4/23

#include <ctype.h>
#include <stdio.h>
#define MAX_LENGTH 101

// this function gets the length of a string
int getLength(char s[]) {
  int length = 0;
  while (s[length] != '\0') {
    length++;
  }
  return length;
}

// this function checks if the two strings are the same
int is_equal(char s1[], char s2[]) {
  int i = 0;
  while (s1[i] != '\0' && s2[i] != '\0') {
    if (s1[i] != s2[i]) {
      return 0;
    }
    i++;
  }
  return (s1[i] == '\0' && s2[i] == '\0');
}

// this function copies one string to another
void str_copy(char dest[], char source[]) {
  int i = 0;
  while (source[i] != '\0') {
    dest[i] = source[i];
    i++;
  }
  dest[i] = '\0';
}

// this function swaps the values of two characters
void swap(char *a, char *b) {
  char temp = *a;
  *a = *b;
  *b = temp;
}

// this function reverses the string
void str_reverse(char s[]) {
  int start = 0;
  int end = getLength(s) - 1;
  while (start < end) {
    swap(&s[start], &s[end]);
    start++;
    end--;
  }
}

// this function checks if the string is a palindrome
int is_palindrome(char s[]) {
  char reversed[MAX_LENGTH];
  str_copy(reversed, s);
  str_reverse(reversed);
  return is_equal(s, reversed);
}

// this function converts the string to uppercase
void capitalize_word(char *str) {
  int i = 0;
  int capitalnext = 1;
  while (str[i] != '\0') {
    if (isalpha(str[i])) {
      if (capitalnext) {
        str[i] = toupper(str[i]);
        capitalnext = 0;
      } else {
        str[i] = tolower(str[i]);
      }
    } else {
      capitalnext = 1;
    }
    i++;
  }
}

int main(void) {

  char s1[MAX_LENGTH];
  char s2[MAX_LENGTH];
  char x;

  printf("Enter a string: ");
  scanf("%[^\n]s", s1);

  while ((x = getchar() != '\n') && x != EOF)
    ; // loop to discard \n from last input and not to skip the next input

  printf("Enter another string: ");
  scanf("%[^\n]s", s2);

  printf("\nThe length of your first string is %d\n", getLength(s1));
  printf("The length of your second string is %d\n", getLength(s2));

  if (is_equal(s1, s2) == 1) {
    printf("You entered two equal strings.\n");
  } else {
    printf("Your strings are different.\n");
  }

  if (is_palindrome(s1)) // make sure you do not change the string
  {
    printf("%s is a palindrome string\n", s1);
  } else {
    printf("%s is not a palindrome string\n", s1);
  }

  capitalize_word(s1);
  printf("Capitalized s1 is %s ", s1);

  return 0;
}