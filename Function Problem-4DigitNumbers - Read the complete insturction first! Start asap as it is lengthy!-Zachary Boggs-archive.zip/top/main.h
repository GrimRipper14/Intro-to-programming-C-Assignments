int isFourDigit(int num);
int reverse4Digit (int num);
void addSides4Digit(int num);
int isPalindrome4Digit(int num);