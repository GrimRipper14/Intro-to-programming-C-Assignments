// Zachary Boggs
// COP 3223C
// 9/25/23

#include "main.h"
#include <stdio.h>

// sets up the reverse and palindrome
int main(void) {
  int num;
  printf("Enter a four digit number:\n");
  scanf("%d", &num);
  int reversed = reverse4Digit(num);
  if (reversed == -1) {
    printf("Invalid to reverse\n");
  } else {
    printf("Reverse is: %d\n", reversed);
  }

  addSides4Digit(num);
  int isPalindrome = isPalindrome4Digit(num);
  if (isPalindrome == 1) {
    printf("Palindrome\n");
  } else if (isPalindrome == 0) {
    printf("Not palindrome\n");
  } else {
    printf("Invalid input for palindrome checker\n");
  }
  return 0;
}

int isFourDigit(int num) {
  if (num >= 1000 && num <= 9999) {
    return 1;
  } else {
    return 0;
  }
}
// Sets up reversing numbers
int reverse4Digit(int num) {
  if (isFourDigit(num)) {
    int digit1, digit2, digit3, digit4;
    digit1 = num % 10;
    num /= 10;
    digit2 = num % 10;
    num /= 10;
    digit3 = num % 10;
    num /= 10;
    digit4 = num % 10;
    return (digit1 * 1000) + (digit2 * 100) + (digit3 * 10) + digit4;
  } else {
    return -1;
  }
}
// Adds the sides together
void addSides4Digit(int num) {
  if (isFourDigit(num)) {
    int digit1, digit4;
    digit1 = num / 1000;
    digit4 = num % 10;
    printf("Sum of sides is: %d\n", digit1 + digit4);
  } else {
    printf("Invalid input to calculate sides\n");
  }
}

int isPalindrome4Digit(int num) {
  int reversed = reverse4Digit(num);
  if (reversed == -1) {
    return -1;
  } else if (num == reversed) {
    return 1;
  } else {
    return 0;
  }
}