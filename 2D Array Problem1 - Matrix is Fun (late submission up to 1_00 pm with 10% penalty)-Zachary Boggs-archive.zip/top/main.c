//Zachary Boggs
// 10/25/23
// matrix is fun
// cop 3223c
#include <stdio.h>
#define MAXROWS 100
#define MAXCOLUMNS 100

//this function displays a matrix
void displayMatrix(int matrix[][MAXCOLUMNS], int rows, int columns) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
            printf("%4d", matrix[i][j]);
        }
        printf("\n");
    }
}
//this function finds the max value per row in a matrix
void findMaxPerRow(int matrix[][MAXCOLUMNS], int rows, int columns) {
    for (int i = 0; i < rows; i++) {
        int max = matrix[i][0];
        for (int j = 1; j < columns; j++) {
            if (matrix[i][j] > max) {
                max = matrix[i][j];
            }
        }
        printf("max of row %d is %d\n", i, max);
    }
}
//this function prints the lower left triangle of a matrix
void printLLTriangle(int matrix[][MAXCOLUMNS], int rows, int columns) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
            if (j <= i) {
                printf("%4d", matrix[i][j]);
            } else {
                printf("%4d", 0);
            }
        }
        printf("\n");
    }
}
//this function prints the upper right triangle of a matrix
void printURTriangle(int matrix[][MAXCOLUMNS], int rows, int columns) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
            if (j >= i) {
                printf("%4d", matrix[i][j]);
            } else {
                printf("%4d", 0);
            }
        }
        printf("\n");
    }
}
//this function adds two matrices and stores the sum in a third matrix
void addMatrix(int M1[][MAXCOLUMNS], int M2[][MAXCOLUMNS], int R[][MAXCOLUMNS], int r, int c) {
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            R[i][j] = M1[i][j] + M2[i][j];
        }
    }
}
//this function calcaultes the sum of surrounding numbers of a matrix element
int sumSurrounding(int matrix[][MAXCOLUMNS], int rows, int columns, int i, int j) {
    int sum = 0;

    if (i-1 >= 0 && j-1 >= 0) {
        sum += matrix[i-1][j-1];
    }
    if (i-1 >= 0) {
        sum += matrix[i-1][j];
    }
    if (i-1 >= 0 && j+1 < columns) {
        sum += matrix[i-1][j+1];
    }
    if (j-1 >= 0) {
        sum += matrix[i][j-1];
    }
    if (j+1 < columns) {
        sum += matrix[i][j+1];
    }
    if (i+1 < rows && j-1 >= 0) {
        sum += matrix[i+1][j-1];
    }
    if (i+1 < rows) {
        sum += matrix[i+1][j];
    }
    if (i+1 < rows && j+1 < columns) {
        sum += matrix[i+1][j+1];
    }

    return sum;
}

int main() {
    int rows, columns;
    printf("Enter number of rows and columns: ");
    scanf("%d %d", &rows, &columns);

    int matrix1[MAXROWS][MAXCOLUMNS];
    int matrix2[MAXROWS][MAXCOLUMNS];
    int resultMatrix[MAXROWS][MAXCOLUMNS];

    printf("Input for matrix 1:\n");
    for (int i = 0; i < rows; i++) {
        printf("Data for matrix1[%d][0] to matrix1[%d][%d] ", i, i, columns-1);
        for (int j = 0; j < columns; j++) {
            scanf("%d", &matrix1[i][j]);
        }
    }

    printf("Input for matrix 2:\n");
    for (int i = 0; i < rows; i++) {
        printf("Data for matrix2[%d][0] to matrix2[%d][%d] ", i, i, columns-1);
        for (int j = 0; j < columns; j++) {
            scanf("%d", &matrix2[i][j]);
        }
    }
    //printing the necessary statements
    printf("\nPrinting matrix 1:\n");
    displayMatrix(matrix1, rows, columns);

    printf("\nPrinting matrix 2:\n");
    displayMatrix(matrix2, rows, columns);

    printf("\nPrinting max per row for matrix 1:\n");
    findMaxPerRow(matrix1, rows, columns);

    printf("\nPrinting lower left triangle of matrix 1:\n");
    printLLTriangle(matrix1, rows, columns);

    printf("\nPrinting upper right triangle for matrix 1:\n");
    printURTriangle(matrix1, rows, columns);

    addMatrix(matrix1, matrix2, resultMatrix, rows, columns);
    printf("\nMatrix 1 + Matrix 2 is:\n");
    displayMatrix(resultMatrix, rows, columns);

    //the do while loop to sum up the surrounding numbers
    int i, j;
    do {
        printf("\nEnter i and j for calculating sum of surrounding: ");
        scanf("%d %d", &i, &j);

        if (i < 0 || j < 0) {
            break;
        }

        int sum = sumSurrounding(matrix1, rows, columns, i, j);
        printf("Sum of surrounding is %d\n", sum);
    } while (1);

    printf("\nExit\n");

    return 0;
}