void drive(double *odomPtr, double *fuelPtr, double mpg, double distance);
