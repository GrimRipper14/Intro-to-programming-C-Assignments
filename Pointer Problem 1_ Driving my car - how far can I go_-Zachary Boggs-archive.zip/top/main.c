// Zachary Boggs
// COP 3223C
// 10/29/23
#include "main.h"
#include <stdio.h>

void drive(double *odomPtr, double *fuelPtr, double mpg, double distance) {
  // calculates fuel needed to drive the distance
  double fuelNeeded = distance / mpg;
  // chesks if theres enough fuel to drive the distance
  if (fuelNeeded <= *fuelPtr) {
    // updates the odometer and fuel pointers
    *odomPtr += distance;
    *fuelPtr -= fuelNeeded;
  } else {
    *odomPtr += *fuelPtr * mpg;
    *fuelPtr = 0;
  }
}
int main() {
  double odomPtr, fuelPtr, mpg, distance;
  // input
  printf("Enter odometer reading, fuel gauge reading and mpg: ");
  scanf("%lf %lf %lf", &odomPtr, &fuelPtr, &mpg);
  // loops until the fuel gauge is empty
  while (fuelPtr > 0) {
    printf("Enter the distance you want to drive: ");
    scanf("%lf", &distance);
    // calls the drive function
    drive(&odomPtr, &fuelPtr, mpg, distance);
    // prints the updated values
    printf("Current reading odometer = %.2lf, fuel = %.2lf\n", odomPtr,
           fuelPtr);
  }
  // prints the message when the fuel gauge is empty
  printf("\nNo more fuel!");
  return 0;
}