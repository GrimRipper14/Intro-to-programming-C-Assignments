// Zachary Boggs
// COP 3223
// 11/21/23

#include <stdio.h>
#include <string.h>
#define SIZE_EMP 100
#define SIZE_DEPT 50

// defines the structures

typedef struct Employee {
  char eid[10];
  char lname[50];
  int sal;
} Employee;

typedef struct Dept {
  char eid[10];
  char dname[50];
} Dept;

// reads employee function
int readEmp(Employee ArrayOfEmployees[], char empFileName[]) {
  // opens file
  FILE *f_emp = fopen(empFileName, "r");
  // declares variables
  char eid[10];
  char name[50];
  int salary;
  int empCount = 0;
  while (fscanf(f_emp, " %s %s %d", eid, name, &salary) != EOF) {
    strcpy(ArrayOfEmployees[empCount].eid, eid);
    strcpy(ArrayOfEmployees[empCount].lname, name);
    ArrayOfEmployees[empCount].sal = salary;
    empCount++;
  }
  // closes file
  fclose(f_emp);
  return empCount;
}
void readDept(Dept ArrayOfDepartments[], int *numOfDept, char deptFileName[]) {
  // opens file
  FILE *f_dept = fopen(deptFileName, "r");
  // declares variables
  char eid[10];
  char dname[50];
  int deptCount = 0;
  while (fscanf(f_dept, " %s %s", eid, dname) != EOF) {
    strcpy(ArrayOfDepartments[deptCount].eid, eid);
    strcpy(ArrayOfDepartments[deptCount].dname, dname);
    deptCount++;
  }
  // closes file
  *numOfDept = deptCount;
  fclose(f_dept);
}

void printAll(Employee Arr[], int totalEmp, Dept ArrayOfDepartments[],int totalDept) {
  printf("Printing the list of Employees:\n=================\n");
  for (int i = 0; i < totalEmp; i++) {
    printf("ID: %s\tLName: %s\tSalary: %d\t", Arr[i].eid, Arr[i].lname, Arr[i].sal);
    // checking if the employee is part of a department
    int hasDept = 0;
    // loop through the departments
    for (int j = 0; j < totalDept; j++) {
      if (strcmp(Arr[i].eid, ArrayOfDepartments[j].eid) == 0) {
        printf("Department: %s\n", ArrayOfDepartments[j].dname);
        // set hasDept to 1
        hasDept = 1;
        break;
      }
    }
    // if the employee is not part of a department
    if (hasDept == 0) {
      printf("Department: None\n");
    }
  }
}
void search_employee(Employee Arr[], int totalEmp, Dept ArrayOfDepartments[], int totalDept, char qStr[]) {
  int found = 0;
  for (int i = 0; i < totalEmp; i++) {
    if (strcmp(Arr[i].lname, qStr) == 0) {
      printf("ID: %s\tLName: %s\tSalary: %d\t", Arr[i].eid, Arr[i].lname,
             Arr[i].sal);
      for (int j = 0; j < totalDept; j++) {
        if (strcmp(Arr[i].eid, ArrayOfDepartments[j].eid) == 0) {
          printf("Department: %s\n", ArrayOfDepartments[j].dname);
          found = 1;
          break;
        }
      }
      if (!found) {
        printf("Department: None\n");
      }
      break;
    }
  }
  if (!found) {
    printf("Employee %s Not Found\n", qStr);
  }
}
int totalSal_dept(Employee Arr[], int totalEmp, Dept ArrayOfDepartments[], int totalDept, char qStr[]) {
    int totalSal = 0;
    for (int i = 0; i < totalDept; i++) {
      if (strcmp(ArrayOfDepartments[i].dname, qStr) == 0) {
        for (int j = 0; j < totalEmp; j++) {
          if (strcmp(Arr[j].eid, ArrayOfDepartments[i].eid) == 0) {
            totalSal += Arr[j].sal;
          }
        }
      }
    }
    return totalSal;
  }

int main(void) {
  char empFileName[51], deptFileName[51], queryFileName[51];
  scanf(" %s %s %s", empFileName, deptFileName, queryFileName);
  // declare variables
  Employee empList[SIZE_EMP];
  Dept deptList[SIZE_DEPT];
  // get total num of employees
  int total_emp = readEmp(empList, empFileName);
  // get department total
  int total_dept;
  readDept(deptList, &total_dept, deptFileName);
  // print all
  printAll(empList, total_emp, deptList, total_dept);
  printf("Query Phase\n");
  // open file
  FILE *qf = fopen(queryFileName, "r");
  int numQueries;
  fscanf(qf, " %d", &numQueries);
  // create a for loop from 0. to numQueries
  for (int i = 0; i < numQueries; i++) {
    // delcare variables
    int query;
    char qStr[100];
    // scan the query
    fscanf(qf, " %d %s", &query, qStr);
    // check if query is 1 or 2
    if (query == 1) {
      search_employee(empList, total_emp, deptList, total_dept, qStr);
    } else if (query == 2) {
      int totalSal =
          totalSal_dept(empList, total_emp, deptList, total_dept, qStr);
      printf("Total Salary of Department %s is %d\n", qStr, totalSal);
    }
  }
  // close the file
  fclose(qf);

  return 0;
}