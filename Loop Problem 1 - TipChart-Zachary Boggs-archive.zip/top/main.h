#define TIP_RATE 0.10
void printTipChart(int min_price, int max_price);