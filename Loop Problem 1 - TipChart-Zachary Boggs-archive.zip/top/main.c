// Zachary Boggs
// Loop problem 1
// COP 3223C
// 10/1/23
#include <stdio.h>

// defines the tip rate as constant
#define TIP_RATE 0.10

void printTipChart(int min_price, int max_price) {
  // the initial statement taht moves the for loop up one each time if the
  // second statement is true
  for (int Meal_Price = min_price; Meal_Price <= max_price; Meal_Price++) {
    if (Meal_Price < 0) {
      return;
      // stops if the meal price is negative
    }
    // double stores the tip amount which is taking the tip rate away from the
    // meal price
    double Tip_Amount = Meal_Price * TIP_RATE;
    printf("On a meal of $%d, the suggested tip amount $%.2lf\n", Meal_Price,
           Tip_Amount);
  }
}

// declares the variables
int main() {
  int min_price, max_price;
  int Valid_Tips = 0;

  // runs once to determine whether the min and max price are negative or not
  while (1) {
    printf("Enter the minimum and maximum meal values: ");
    scanf("%d %d", &min_price, &max_price);
    // if negative the program stops
    if (min_price < 0 || max_price < 0) {
      break;
    }

    // if negative min and max prices are found the functions scores how much
    // valid tips were generated
    if (min_price <= max_price) {
      Valid_Tips++;

      printTipChart(min_price, max_price);
    }
  }
  // prints the amount of valid tips
  printf("You have printed total %d valid charts\n", Valid_Tips);

  return 0;
}