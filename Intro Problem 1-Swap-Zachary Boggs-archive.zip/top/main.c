//Zachary Boggs
//COP3223C

#include <stdio.h>

int main(void) {
  int a, b;

  scanf("%d%d", &a, &b);
  printf("Before swapping, a is %d and b is %d", a, b);

  int number = a;
  a = b;
  b = number;

  printf("\nAfter Swapping, a is %d and b is %d\n", a, b);
  return 0;
}