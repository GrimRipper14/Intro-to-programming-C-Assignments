#define SIZE 200
int isPrime(int n);
void PrimeMatching(int array1[], int size1, int array2[], int size2);
int findSmallest(int array[], int size);
int findLargest(int array[], int size);