// Zachary Boggs
// COP 3223C
// 10/15/23

#include <stdio.h>
#include "main.h"
#define SIZE 200

//sees if it's prime or not
int isPrime(int n) {
  if (n <= 1) {
    return 0; // 1 is not prime
  }
  for (int i = 2; i < n; i++) {
    if (n % i == 0) {
      return 0; // Not prime
    }
  }
  return 1; // Prime
}
//sets up the prime matching, to match the prime numbers
void PrimeMatching(int array1[], int size1, int array2[], int size2) {
  printf("Common prime numbers are: ");
  int count = 0;
//sets array i equal to array j
  for (int i = 0; i < size1; i++) {
    if (isPrime(array1[i])) {
      for (int j = 0; j < size2; j++) {
        if (array1[i] == array2[j]) {
          printf("%d ", array1[i]);
          count++;
          break;
        }
      }
    }
  }

  printf("\nCommon count: %d\n", count);
}
//this finds the smallest number
int findSmallest(int array[], int size) {
  int smallest = array[0];
  for (int i = 1; i < size; i++) {
    if (array[i] < smallest) {
      smallest = array[i];
    }
  }
  return smallest;
}
//this finds the largest number
int findLargest(int array[], int size) {
  int largest = array[0];
  for (int i = 1; i < size; i++) {
    if (array[i] > largest) {
      largest = array[i];
    }
  }
  return largest;
}

int main() {
  int n, m;
  int list1[SIZE], list2[SIZE];
//having the user input the numbers
  printf("Enter n and m: ");
  scanf("%d %d", &n, &m);
//this adds the numbers to the array
  printf("Enter data for first list: ");
  for (int i = 0; i < n; i++) {
    scanf("%d", &list1[i]);
  }
//this adds the second numbers to the second array
  printf("Enter data for second list: ");
  for (int i = 0; i < m; i++) {
    scanf("%d", &list2[i]);
  }

  PrimeMatching(list1, n, list2, m);

  int smallest = findSmallest(list2, m);
  int largest = findLargest(list2, m);

  printf("Smallest number in the second list: %d\n", smallest);
  printf("Largest number in the second list: %d\n", largest);

  return 0;
}