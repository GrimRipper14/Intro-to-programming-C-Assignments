// Zachary Boggs
// COP 3223
// 9/13/23

#include <math.h>
#include <stdio.h>

int main(void) {
  float x1, x2, x3, y1, y2, y3;
  // Takes in 3 cooridnate inputs from user
  printf("Enter coordinates (x1,y1):\n");
  scanf("%f %f", &x1, &y1);
  printf("Enter coordinates (x2,y2):\n");
  scanf("%f %f", &x2, &y2);
  printf("Enter coordinates (x3,y3):\n");
  scanf("%f %f", &x3, &y3);

  // Calculates the 2 slops for copmarision
  float slope1 = (y2 - y1) / (x2 - x1);
  float slope2 = (y3 - y1) / (x3 - x1);

  // Compares the two slopes to determing if their on the same line
    if (fabs(slope1 - slope2) < 0.000001) {
    printf("They fall on one straight line \n");
  } 
    else {
    printf("They do not fall on one straight line");
  }
  return 0;
}